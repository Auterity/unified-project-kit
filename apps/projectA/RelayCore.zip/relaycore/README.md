# RelayCore: AI Integration Gateway

RelayCore is a developer-first, universal HTTP relay service that connects any external tool (IDEs, CLIs, agent orchestrators) to AI model endpoints. It enables smart routing, cost optimization, context injection, and plug-and-play agent interoperability.

![RelayCore Architecture](https://via.placeholder.com/800x400?text=RelayCore+Architecture)

## Key Features

- **AI Request Router**: Intelligently route requests to the most appropriate AI model based on cost, performance, and capability requirements
- **Semantic Input Deduplication**: Identify and merge duplicate or semantically similar requests
- **Configurable Agent Profiles**: Create and manage profiles for different use cases and requirements
- **Advanced Caching System**: Multi-level caching with semantic similarity matching
- **Token & Cost Tracking**: Comprehensive analytics on usage and costs
- **Plugin Ecosystem**: Extensible architecture with plugins for VS Code, Claude CLI, LangChain, and more

## Why RelayCore?

- **Reduce AI API Costs**: Save up to 50% on API costs through intelligent caching, batching, and optimization
- **Unified Interface**: One API to connect all your AI tools and models
- **Developer Experience**: Seamless integration with your favorite IDEs and tools
- **Cost Visibility**: Comprehensive analytics and monitoring of AI usage and costs
- **Extensibility**: Plugin system for adding new integrations and capabilities

## Getting Started

### Prerequisites

- Node.js 18+
- Redis (optional, for distributed caching)
- PostgreSQL (optional, for analytics)

### Installation

#### Using Docker (Recommended)

```bash
# Clone the repository
git clone https://github.com/ninjatech/relaycore.git
cd relaycore

# Configure environment variables
cp .env.example .env
# Edit .env with your API keys and configuration

# Start with Docker Compose
docker-compose up -d
```

#### Manual Installation

```bash
# Clone the repository
git clone https://github.com/ninjatech/relaycore.git
cd relaycore

# Install dependencies
npm install

# Configure environment variables
cp .env.example .env
# Edit .env with your API keys and configuration

# Build the project
npm run build

# Start the server
npm start
```

### Configuration

RelayCore is configured using a YAML configuration file. See [examples/relaycore.config.yaml](examples/relaycore.config.yaml) for a complete example.

```yaml
# Basic configuration example
server:
  port: 3000
  host: "0.0.0.0"

providers:
  openai:
    enabled: true
    apiKey: "${OPENAI_API_KEY}"
    baseUrl: "https://api.openai.com"
  
  anthropic:
    enabled: true
    apiKey: "${ANTHROPIC_API_KEY}"
    baseUrl: "https://api.anthropic.com"
```

## Usage Examples

### Basic Request

```bash
curl -X POST "http://localhost:3000/v1/openai/chat/completions" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your_api_key_here" \
  -d '{
    "model": "gpt-4",
    "messages": [
      {"role": "system", "content": "You are a helpful assistant."},
      {"role": "user", "content": "What is the capital of France?"}
    ],
    "temperature": 0.7,
    "max_tokens": 150
  }'
```

### Request with Caching and Optimization

```bash
curl -X POST "http://localhost:3000/v1/openai/chat/completions" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your_api_key_here" \
  -H "X-AIHub-Cache: use" \
  -H "X-AIHub-Optimize: moderate" \
  -d '{
    "model": "gpt-4",
    "messages": [
      {"role": "system", "content": "You are a helpful assistant."},
      {"role": "user", "content": "What is the capital of France?"}
    ],
    "temperature": 0.7,
    "max_tokens": 150
  }'
```

## API Documentation

### Core Endpoints

- `POST /v1/{provider}/chat/completions` - Chat completions endpoint
- `POST /v1/{provider}/completions` - Text completions endpoint
- `POST /v1/{provider}/embeddings` - Embeddings endpoint

### Batch Processing

- `POST /v1/batch` - Submit batch request
- `GET /v1/batch/{batchId}` - Get batch status
- `DELETE /v1/batch/{batchId}` - Cancel batch

### Cache Management

- `GET /v1/cache/stats` - Get cache statistics
- `POST /v1/cache/clear` - Clear cache
- `DELETE /v1/cache/{cacheKey}` - Delete specific cache entry

### Analytics

- `GET /v1/analytics/usage` - Get usage statistics
- `GET /v1/analytics/costs` - Get cost statistics
- `GET /v1/analytics/requests` - Get request history
- `GET /v1/analytics/optimizations` - Get optimization statistics

## Plugins

RelayCore supports a variety of plugins for integration with different tools and frameworks:

### VS Code Extension

Our VS Code extension provides seamless integration with the popular IDE:

- **Code Explanation**: Get clear explanations of selected code
- **Documentation Generation**: Automatically create documentation for your code
- **Code Optimization**: Improve your code's performance and readability
- **AI Assistance**: Ask questions about your code and get intelligent answers

[Learn more about the VS Code plugin](./plugins/vscode/README.md)

### Claude CLI Plugin

Interact with Claude models directly from your terminal:

- **Interactive Chat**: Have conversations with Claude in your terminal
- **File Processing**: Include file contents in your prompts
- **Command Integration**: Pipe command outputs to Claude
- **Custom System Messages**: Set specific instructions for different use cases

[Learn more about the Claude CLI plugin](./plugins/claude-cli/README.md)

### LangChain Integration

Use RelayCore as a provider in LangChain applications:

- **RelayCoreLLM**: Use RelayCore as a standard LangChain LLM
- **RelayCoreChat**: Use RelayCore as a LangChain Chat Model
- **Provider Flexibility**: Switch between different AI providers without changing your code
- **Cost Optimization**: Reduce costs through intelligent caching and token optimization

[Learn more about the LangChain integration](./plugins/langchain/README.md)

### Other Integrations

- **LangGraph Node**: Custom node for LangGraph workflows
- **TaskWeaver Plugin**: Integration with Microsoft's TaskWeaver

## Dashboard

RelayCore includes a modern, responsive web dashboard for monitoring usage, costs, and configuration:

![RelayCore Dashboard](https://via.placeholder.com/800x400?text=RelayCore+Dashboard)

Features include:
- Request logs and history
- Cost analytics and visualization
- Configuration management
- User and team management
- Plugin management

### Dashboard UI

Our dashboard is built with a comprehensive design system that includes:

- **Modern Component Library**: Buttons, forms, cards, tables, and more
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Dark/Light Themes**: Choose your preferred visual style
- **Interactive Visualizations**: Charts and graphs for data analysis
- **User-Friendly Interface**: Intuitive navigation and controls

## Website

The RelayCore website provides comprehensive information about the product:

- **Feature Overview**: Detailed explanation of RelayCore capabilities
- **Documentation**: Comprehensive guides and API reference
- **Pricing Plans**: Transparent pricing information
- **Blog**: Latest updates and technical articles
- **Contact Information**: Easy ways to reach our team

## Development

### Project Structure

```
relaycore/
├── src/
│   ├── api/           # API routes
│   ├── core/          # Core functionality
│   ├── providers/     # Provider adapters
│   ├── cache/         # Caching system
│   ├── optimization/  # Optimization engine
│   ├── analytics/     # Analytics and monitoring
│   ├── batch/         # Batch processing
│   ├── plugins/       # Plugin system
│   ├── config/        # Configuration management
│   ├── utils/         # Utility functions
│   └── index.ts       # Entry point
├── dashboard/         # Web dashboard
├── plugins/           # Plugin directory
│   ├── vscode/        # VS Code plugin
│   ├── claude-cli/    # Claude CLI plugin
│   └── langchain/     # LangChain integration
├── relaycore-ui/      # UI components
│   ├── design-system/ # Design system components
│   ├── dashboard/     # Dashboard UI
│   └── website/       # Marketing website
├── tests/             # Tests
├── dist/              # Compiled code
├── kubernetes/        # Kubernetes deployment files
├── .github/           # GitHub workflows
├── relaycore.config.yaml  # Configuration file
└── .env               # Environment variables
```

### Running Tests

```bash
# Run all tests
npm test

# Run specific test suite
npm test -- --testPathPattern=cache
```

### Building

```bash
# Build the project
npm run build
```

### Deployment

RelayCore can be deployed using Docker or Kubernetes:

#### Docker Deployment

```bash
docker run -p 3000:3000 \
  -e OPENAI_API_KEY=your-openai-api-key \
  -e ANTHROPIC_API_KEY=your-anthropic-api-key \
  -e REDIS_URL=redis://redis:6379 \
  relaycore/relaycore:latest
```

#### Kubernetes Deployment

```bash
# Apply the Kubernetes manifests
kubectl apply -f kubernetes/relaycore-config.yaml
kubectl apply -f kubernetes/redis-deployment.yaml
kubectl apply -f kubernetes/relaycore-deployment.yaml
kubectl apply -f kubernetes/monitoring.yaml
```

## Contributing

We welcome contributions to RelayCore! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for details on how to get started.

## License

RelayCore is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- **Documentation**: [docs.relaycore.ai](https://docs.relaycore.ai)
- **GitHub Issues**: [github.com/ninjatech/relaycore/issues](https://github.com/ninjatech/relaycore/issues)
- **Discord**: [discord.gg/relaycore](https://discord.gg/relaycore)
- **Email**: support@relaycore.ai